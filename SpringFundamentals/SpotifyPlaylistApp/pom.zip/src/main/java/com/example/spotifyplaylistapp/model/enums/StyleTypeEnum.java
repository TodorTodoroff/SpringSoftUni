package com.example.spotifyplaylistapp.model.enums;

public enum StyleTypeEnum {
    POP, ROCK, JAZZ
}
